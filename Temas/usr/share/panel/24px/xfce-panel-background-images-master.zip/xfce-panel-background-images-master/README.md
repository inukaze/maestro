# xfce-panel-background-images
Some images for xfce-panel's background
Some of this images created by me and some of them not!
I maked my images by Gimp! 
License : GPL3
feel free to modify and share and add your images to this repository!

1- download the images folder or clone this repository
2 - Right click on your xfce panel
	Go to Panel(Panel > Preferences > appearance)
3 - Select Backgroung image from Style.
4 - select your desired image file from File.
5 - Enjoy!


## Some Screenshots
![ScreenShot](http://s6.picofile.com/file/8202702626/pdmt.jpg)


![ScreenShot](http://s6.picofile.com/file/8251316068/numix_panel.jpg)



## Contact me
Me on twiter:
https://twitter.com/AR_AmirSamimi

My Personal Website:
http://amirsamimi.ir

My email adress:
alireza.amirsamimi@ubuntu.ir
